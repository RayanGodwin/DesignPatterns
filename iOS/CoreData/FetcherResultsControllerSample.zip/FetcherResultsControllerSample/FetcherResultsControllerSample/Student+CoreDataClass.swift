//
//  Student+CoreDataClass.swift
//  FetcherResultsControllerSample
//
//  Created by Rayan Sequeira on 25/04/18.
//  Copyright © 2018 Rayan Sequeira. All rights reserved.
//
//

import Foundation
import CoreData


public class Student: NSManagedObject {

}
