//
//  ViewController.swift
//  FetcherResultsControllerSample
//
//  Created by Rayan Sequeira on 25/04/18.
//  Copyright © 2018 Rayan Sequeira. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var studentTableView: UITableView!
    var fetchedResultsController: NSFetchedResultsController<NSFetchRequestResult>!
    lazy var appDelegate: AppDelegate = {
        let appDel:AppDelegate = (UIApplication.shared.delegate as! AppDelegate)
        return appDel
    }()
    lazy var persistentContainer: NSPersistentContainer = {
        return appDelegate.persistentContainer
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.setAddButton()
        self.setEditButton()
        self.fetchAllStudentList()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setAddButton() {
        let rightAddItem = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonSystemItem.add, target: self, action: #selector(ViewController.moveToAddViewController))
        self.navigationItem.rightBarButtonItem = rightAddItem
    }
    
    func setEditButton() {
        let leftEditItem = UIBarButtonItem.init(barButtonSystemItem: UIBarButtonSystemItem.edit, target: self, action: #selector(ViewController.makeTableViewEditable))
        self.navigationItem.leftBarButtonItem = leftEditItem
    }
    
    func addEntry(with firstName: String, and lastName: String) {
        persistentContainer.performBackgroundTask { (context) in
            for i in 0...5 {
                guard let entity = NSEntityDescription.entity(forEntityName: "Student", in:context) else {
                    continue
                }
                
                let newStudent = Student(entity:entity, insertInto:context)
                newStudent.firstName = firstName
                newStudent.lastName = lastName
                newStudent.rollNo = Int16(i)
            }
            
            do {
                try context.save()
            } catch let error as NSError {
                print("Error saving movie \(error.localizedDescription)")
            }
        }
    }
    
    func fetchAllStudentList() {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
        let fetchSort = NSSortDescriptor(key: "rollNo", ascending: true)
        fetchRequest.sortDescriptors = [fetchSort]
        fetchRequest.fetchBatchSize = 20
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: persistentContainer.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self
        do {
            try fetchedResultsController.performFetch()
        } catch let error as NSError {
            print("Unable to perform fetch: \(error.localizedDescription)")
        }
    }
    
    @objc func moveToAddViewController() {
        addEntry(with: "Rayan", and: "Sequeira")
    }
    
    @objc func makeTableViewEditable() {
        self.studentTableView.isEditing = !self.studentTableView.isEditing
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        guard let sectionCount = fetchedResultsController?.sections?.count else {
            return 0
        }
        return sectionCount
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let sectionData = fetchedResultsController?.sections?[section] else {
            return 0
        }
        return sectionData.numberOfObjects
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StudentCell", for: indexPath) as! StudentTableViewCell
        configureCell(cell: cell, forRowAtIndexPath: indexPath)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 64
    }
    
    func configureCell(cell: StudentTableViewCell, forRowAtIndexPath: IndexPath) {
        let student = fetchedResultsController?.object(at: forRowAtIndexPath as IndexPath) as! Student
        guard let firstName = student.value(forKey: "firstName") as? String,
            let lastName = student.value(forKey: "lastName") as? String,
            let rollNumber = student.value(forKey: "rollNo") as? Int16 else {
            return
        }
        cell.nameLabel?.text = firstName + " " + lastName
        cell.rollNumberLabel?.text = String(rollNumber)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        switch editingStyle {
        case .delete:
            let student = fetchedResultsController.object(at: indexPath) as! Student
            persistentContainer.performBackgroundTask { (context) in
                let objectToDelete = context.object(with: student.objectID)
                context.delete(objectToDelete)
                context.performAndWait {
                    do {
                        try context.save()
                    } catch let error as NSError {
                        print("Error saving context after delete: \(error.localizedDescription)")
                    }
                }
            }
        default:break
        }
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, shouldIndentWhileEditingRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        guard var objects = self.fetchedResultsController?.fetchedObjects as? [Student] else { return }
        self.fetchedResultsController?.delegate = nil
        
        let object = objects[sourceIndexPath.row]
        objects.remove(at: sourceIndexPath.row)
        objects.insert(object, at: destinationIndexPath.row)
        
        for (index, item) in objects.enumerated() {
            item.rollNo = Int16(index)
        }
        
        appDelegate.saveContext()
        self.fetchedResultsController?.delegate = self
    }
}

extension ViewController: NSFetchedResultsControllerDelegate {
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        studentTableView.beginUpdates()
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        studentTableView.endUpdates()
    }
    
    func controller(controller: NSFetchedResultsController<NSFetchRequestResult>, didChangeSection sectionInfo: NSFetchedResultsSectionInfo, atIndex sectionIndex: Int, forChangeType type: NSFetchedResultsChangeType) {
        switch type {
        case .insert:
            studentTableView.insertSections(NSIndexSet(index: sectionIndex) as IndexSet, with: .automatic)
        case .delete:
            studentTableView.deleteSections(NSIndexSet(index: sectionIndex) as IndexSet, with: .automatic)
        default: break
        }
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch(type) {
            
        case .insert:
            studentTableView.insertRows(at: [newIndexPath!], with: UITableViewRowAnimation.fade)
            break;
            
        case .delete:
            studentTableView.deleteRows(at: [indexPath!], with: UITableViewRowAnimation.fade)
            break;
            
        case .update:
            self.configureCell(cell: studentTableView.cellForRow(at: indexPath!) as! StudentTableViewCell, forRowAtIndexPath:indexPath!)
            break;
            
        case .move:
            studentTableView.deleteRows(at: [indexPath!], with: UITableViewRowAnimation.fade)
            studentTableView.insertRows(at: [newIndexPath!], with: UITableViewRowAnimation.fade)
            break;
        }
    }
}

