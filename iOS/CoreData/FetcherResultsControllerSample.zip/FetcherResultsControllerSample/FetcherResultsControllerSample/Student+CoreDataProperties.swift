//
//  Student+CoreDataProperties.swift
//  FetcherResultsControllerSample
//
//  Created by Rayan Sequeira on 25/04/18.
//  Copyright © 2018 Rayan Sequeira. All rights reserved.
//
//

import Foundation
import CoreData


extension Student {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Student> {
        return NSFetchRequest<Student>(entityName: "Student")
    }

    @NSManaged public var firstName: String?
    @NSManaged public var rollNo: Int16
    @NSManaged public var lastName: String?

}
