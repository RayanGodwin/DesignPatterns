//
//  StudentTableViewCell.swift
//  FetcherResultsControllerSample
//
//  Created by Rayan Sequeira on 25/04/18.
//  Copyright © 2018 Rayan Sequeira. All rights reserved.
//

import UIKit

class StudentTableViewCell: UITableViewCell {

    @IBOutlet weak var rollNumberLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
