//
//  AppDelegate.h
//  WeekSample
//
//  Created by Rayan Sequeira on 26/06/18.
//  Copyright © 2018 Rayan Sequeira. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

