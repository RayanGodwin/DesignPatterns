//
//  ViewController.m
//  WeekSample
//
//  Created by Rayan Sequeira on 26/06/18.
//  Copyright © 2018 Rayan Sequeira. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSDate * date1 = firstMondayOfMonth(@"November", 2014);
    NSDate * date2 = lastSundayOfMonth(@"December", 2014);
    int weeks = differenceBetweenDate(date1, date2);
    NSLog(@"%d",weeks);
}


int monthOfTheYear(NSString *month)  {
    NSDictionary *months = @{@"January" : @1, @"February": @2, @"March": @3, @"April": @4, @"May": @5, @"June": @6, @"July": @7, @"August": @8, @"September": @9, @"October": @10, @"November": @11, @"December": @12};
    return [months[month] intValue];
}

NSDateComponents* getDateComponents(int weekday, int weekdayOrdinal, int month, int year) {
    NSDateComponents *components = [[NSDateComponents alloc] init];
    [components setWeekday:2];
    [components setWeekdayOrdinal:1];
    [components setMonth:month];
    [components setYear:year];
    return components;
}

NSDate* firstMondayOfMonth(NSString * month, int year) {
    NSDateComponents* components = getDateComponents(3,1,(monthOfTheYear(month)),year);
    NSCalendar *usersCalendar = [[NSLocale currentLocale] objectForKey:NSLocaleCalendar];
    NSDate *date = [usersCalendar dateFromComponents:components];
    return date;
}

NSDate* lastSundayOfMonth(NSString * month, int year) {
    int yearToCalculate = year;
    int monthToUse = monthOfTheYear(month);
    if (monthToUse == 12) {
        yearToCalculate = yearToCalculate + 1;
        monthToUse = 1;
    } else {
        monthToUse = monthToUse + 1;
    }
    NSDateComponents* components = getDateComponents(2,1,monthToUse,yearToCalculate);
    NSCalendar *usersCalendar = [[NSLocale currentLocale] objectForKey:NSLocaleCalendar];
    NSDate *date = [usersCalendar dateFromComponents:components];
    NSDate *dateToReturn = [date dateByAddingTimeInterval: -604800];
    return dateToReturn;
}


float differenceBetweenDate(NSDate *date1, NSDate *date2) {
    NSCalendar *usersCalendar = [[NSLocale currentLocale] objectForKey:NSLocaleCalendar];
    NSDateComponents *components = [usersCalendar components:NSCalendarUnitDay
                                                    fromDate:date1
                                                      toDate:date2
                                                     options:0];
    float weeks = [components day]/7.0;
    return (int)ceilf(weeks);
}

int solution(int year, NSString *firstMonth, NSString *secondMonth, NSString *firstWeekDate) {
    // write your code in Objective-C 2.0
    NSDate * date1 = firstMondayOfMonth(firstMonth, year);
    NSDate * date2 = lastSundayOfMonth(secondMonth, year);
    int weeks = differenceBetweenDate(date1, date2);
    return weeks;
}




@end
